#pragma once
#include"Nation.h"

class GL :public Nation {
public:
	GL(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class NA :public Nation {
public:
	NA(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class MA :public Nation {
public:
	MA(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class SA :public Nation {
public:
	SA(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class UR :public Nation {
public:
	UR(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class AF :public Nation {
public:
	AF(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class OS :public Nation {
public:
	OS(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
class AS :public Nation {
public:
	AS(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
};
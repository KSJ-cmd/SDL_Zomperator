#pragma once

#include"Command.h"
class SDLGameObject;
class Cmd_Xbutton : public ICommand {
public:
	Cmd_Xbutton(SDLGameObject* _deleteTarget);
	~Cmd_Xbutton();
	void execute();
private:
	SDLGameObject* m_deleteTarget;
};
#pragma once
#include"Game.h"

class HpBar {
public:

	HpBar(int hp, const Vector2D& position, const Vector2D& area);
	HpBar(const HpBar& src) = default;
	HpBar& operator=(const HpBar& rsh) = default;

	void set(int hp);
	int get() const;
	void draw();
private:
	int m_maxHp;
	int m_curHp;
	float m_maxW;
	SDL_Rect rect_bgHpbar;
	SDL_Rect rect_maxHpbar;
	SDL_Rect rect_curHpbar;
};
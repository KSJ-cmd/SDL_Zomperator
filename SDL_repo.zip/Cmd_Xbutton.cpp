#include"Cmd_Xbutton.h"
#include"SDLGameObject.h"

Cmd_Xbutton::Cmd_Xbutton(SDLGameObject* _deleteTarget)
	:m_deleteTarget(_deleteTarget)
{
}

Cmd_Xbutton::~Cmd_Xbutton()
{
}

void Cmd_Xbutton::execute()
{
	delete m_deleteTarget;
	delete this;
}

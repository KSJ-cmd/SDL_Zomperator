#pragma once

__interface IObserver {
public:
	virtual void Notify() = 0;
};


#pragma once
#include<list>
#include"Observer.h"

class Subject {
public:
	void Attach(IObserver* observer);
	void Detach(IObserver* observer);
	void Notify();
private:
	std::list<IObserver*> m_Observers;
};
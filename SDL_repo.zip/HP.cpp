#include"HP.h"

Hp::Hp(int amount)
	:m_Data(amount) {

}

bool Hp::Use()
{
	if (m_Data > 0) {
		m_Data--;
		return true;
	}
	else {
		return false;
	}
}

void Hp::Take()
{
}

int Hp::get() const
{
	return m_Data;
}

void Hp::set(int Data)
{
	m_Data = Data;
}

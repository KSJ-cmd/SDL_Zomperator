#pragma once

__interface IUse {
public:
	virtual bool Use() = 0;
};
#include"Button.h"
#include"Playroom.h"
Button::Button(const std::unique_ptr<LoaderParams*>& pParams)
	:SDLGameObject(pParams)
	, m_Command(nullptr)
{
	Playroom::getButtons().push_back(this);
}

Button::Button(const std::unique_ptr<LoaderParams*>& pParams, Vector2D scale)
	: SDLGameObject(pParams, scale)
	, m_Command(nullptr) 
{
	Playroom::getButtons().push_back(this);
	delete m_Command;
}

Button::~Button()
{
	Playroom::getButtons().remove(this);
}


void Button::update(){
}
void Button::draw() {
	SDLGameObject::draw();
}

void Button::setCommand(ICommand* command)
{
	m_Command = command;
}

void Button::OnClick()
{
	if (m_Command != nullptr)
		m_Command->execute();
}

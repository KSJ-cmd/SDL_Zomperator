#include"Playroom.h"
#include"NationHandler.h"
#include"country.h"
#include<algorithm>

std::vector<Nation*> NationHandler::m_Nations;
NationHandler::NationHandler()
{
	std::unique_ptr<LoaderParams*> _GL = std::make_unique<LoaderParams*>(new LoaderParams(714, 247, "Alive_place_0", "GL"));
	GL* newGL = new GL(_GL, Vector2D(140, 260), Vector2D(210, 25));
	m_Nations.push_back(newGL);
	Playroom::getGameObjects().push_back(newGL);

	std::unique_ptr<LoaderParams*> _NA = std::make_unique<LoaderParams*>(new LoaderParams(516, 294, "Alive_place_0", "NA"));
	NA* newNA = new NA(_NA, Vector2D(140, 357), Vector2D(210, 25));
	m_Nations.push_back(newNA);
	Playroom::getGameObjects().push_back(newNA);

	std::unique_ptr<LoaderParams*> _MA = std::make_unique<LoaderParams*>(new LoaderParams(593, 360, "Alive_place_0", "MA"));
	MA* newMA = new MA(_MA, Vector2D(140, 454), Vector2D(210, 25));
	m_Nations.push_back(newMA);
	Playroom::getGameObjects().push_back(newMA);

	std::unique_ptr<LoaderParams*> _SA = std::make_unique<LoaderParams*>(new LoaderParams(668, 495, "Alive_place_0", "SA"));
	SA* newSA = new SA(_SA, Vector2D(140, 551), Vector2D(210, 25));
	m_Nations.push_back(newSA);
	Playroom::getGameObjects().push_back(newSA);

	std::unique_ptr<LoaderParams*> _UR = std::make_unique<LoaderParams*>(new LoaderParams(860, 329, "Alive_place_0", "UR"));
	UR* newUR = new UR(_UR, Vector2D(1250, 260), Vector2D(210, 25));
	m_Nations.push_back(newUR);
	Playroom::getGameObjects().push_back(newUR);

	std::unique_ptr<LoaderParams*> _AF = std::make_unique<LoaderParams*>(new LoaderParams(853, 442, "Alive_place_0", "AF"));
	AF* newAF = new AF(_AF, Vector2D(1250, 357), Vector2D(210, 25));
	m_Nations.push_back(newAF);
	Playroom::getGameObjects().push_back(newAF);

	std::unique_ptr<LoaderParams*> _OS = std::make_unique<LoaderParams*>(new LoaderParams(1098, 514, "Alive_place_0", "OS"));
	OS* newOS = new OS(_OS, Vector2D(1250, 454), Vector2D(210, 25));
	m_Nations.push_back(newOS);
	Playroom::getGameObjects().push_back(newOS);

	std::unique_ptr<LoaderParams*> _AS = std::make_unique<LoaderParams*>(new LoaderParams(1011, 329, "Alive_place_0", "AS"));
	AS* newAS = new AS(_AS, Vector2D(1250, 551), Vector2D(210, 25));
	m_Nations.push_back(newAS);
	Playroom::getGameObjects().push_back(newAS);

}

std::vector<Nation*>& NationHandler::getNations()
{
	return m_Nations;
}

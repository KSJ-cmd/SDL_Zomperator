#include"ResourceData.h"
ResourceData::ResourceData(Weapon* weapon, Medicine* medicine, Food* food)
	:m_Weapon(weapon),m_Medicine(medicine),m_Food(food)
{
}

ResourceData::~ResourceData()
{
	delete m_Weapon;
	delete m_Medicine;
	delete m_Food;
}

ResourceData& ResourceData::operator=(const ResourceData& rsh)
{
	m_Weapon = new Weapon(*rsh.m_Weapon);
	m_Medicine = new Medicine(*rsh.m_Medicine);
	m_Food = new Food(*rsh.m_Food);
	return *this;
}

Weapon* ResourceData::getWP()
{
	return m_Weapon;
}

Medicine* ResourceData::getMD()
{
	return m_Medicine;
}

Food* ResourceData::getFD()
{
	return m_Food;
}


#include"MD.h"

Medicine::Medicine(int amount)
	:m_Data(amount) {

}

bool Medicine::Use()
{
	if (m_Data > 0) {
		m_Data--;
		return true;
	}
	else {
		return false;
	}
}

void Medicine::Take()
{
}

int Medicine::get() const
{
	return m_Data;
}

void Medicine::set(int Data)
{
	m_Data = Data;
}

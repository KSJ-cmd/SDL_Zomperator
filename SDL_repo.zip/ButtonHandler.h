#pragma once
#include"Button.h"

class ButtonHandler {
public:
	ButtonHandler();
private:
};
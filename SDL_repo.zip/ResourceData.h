#pragma once
#include"WP.h"
#include"FD.h"
#include"MD.h"
class ResourceData {
public:
	ResourceData(Weapon* weapon, Medicine* medicine, Food* food);
	~ResourceData();
	ResourceData& operator=(const ResourceData& rsh);

	Weapon* getWP();
	Medicine* getMD();
	Food* getFD();
private:
	ResourceData(const ResourceData& src);

	Weapon* m_Weapon;
	Medicine* m_Medicine;
	Food* m_Food;
};
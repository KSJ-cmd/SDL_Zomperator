#pragma once
#include"SDLGameObject.h"
#include"Button.h"
#include"HpBar.h"
#include"HP.h"
#include"WP.h"
#include"MD.h"
#include"FD.h"
enum class NATION
{
	GL = 1,
	NA,
	MA,
	SA,
	UR,
	AF,
	OS,
	AS
};
__interface INationState;
class Nation :public SDLGameObject {
public:
	Nation(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area);
	virtual ~Nation();
	virtual void update();
	virtual void draw();

	void SetSupplyState(INationState* _nationState);

	Hp* getHp() const;
	Weapon* getWp() const;
	Medicine* getMd() const;
	Food* getFd() const;

private:
	Hp* m_Hp;
	Weapon* m_Wp;
	Medicine* m_Md;
	Food* m_Fd;

	INationState* m_State;

	Button* m_supButton;
	HpBar* m_Hpbar;
	bool isAlive;
};

class Nation;
__interface INationState {
public:
	virtual void Click(Nation* nation) = 0;
};
class NormalState : public INationState {
public:
	static NormalState* Instance();
	~NormalState();
	virtual void Click(Nation* nation);
private:
	NormalState() {};
	static NormalState* p_Instance;
};             

class SupplyState : public INationState {
public:
	static SupplyState* Instance();
	~SupplyState();
	virtual void Click(Nation* nation);
private:
	SupplyState() {};
	static SupplyState* p_Instance;
};


#include"country.h"


GL::GL(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	:Nation(pParams, position, area)
{
}
NA::NA(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}
MA::MA(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}
SA::SA(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}
UR::UR(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}
AF::AF(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}

OS::OS(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}
AS::AS(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	: Nation(pParams, position, area)
{
}

#include"FD.h"

Food::Food(int amount)
	:m_Data(amount) {

}

bool Food::Use()
{
	if (m_Data > 0) {
		m_Data--;
		return true;
	}
	else {
		return false;
	}
}

void Food::Take()
{
}

int Food::get() const
{
	return m_Data;
}

void Food::set(int Data)
{
	m_Data = Data;
}

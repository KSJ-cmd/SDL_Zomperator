#pragma once

__interface ICommand {
public:
	virtual void execute() = 0;
};
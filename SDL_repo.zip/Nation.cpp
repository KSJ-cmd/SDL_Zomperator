#include<SDL.h>
#include<SDL_image.h>
#include"Nation.h"
#include"PlayroomHandler.h"

const int MAX = 100;
const int MIN = 0;

Nation::Nation(const std::unique_ptr<LoaderParams*>& pParams, const Vector2D& position, const Vector2D& area)
	:SDLGameObject(pParams)
	, m_Hp(new Hp(MAX)), m_Wp(new Weapon(MAX)), m_Md(new Medicine(MAX)), m_Fd(new Food(MAX)) , isAlive(true)
	, m_State(NormalState::Instance())
	, m_supButton(new Button(pParams))
	, m_Hpbar(new HpBar(m_Hp->get(),position,area))
{
	m_supButton->InActive();
	Playroom::getButtons().push_back(m_supButton); 
}
Nation::~Nation() {
	delete m_supButton;
	delete m_Hpbar;
	delete m_Hp;
	delete m_Wp;
	delete m_Md;
	delete m_Fd;
}
void Nation::update() {
}

void Nation::draw() {
	SDLGameObject::draw();
	m_Hpbar->draw();
}

void Nation::SetSupplyState(INationState* _nationState)
{
	m_State = _nationState;
}



Hp* Nation::getHp() const { 
	return m_Hp; 
}
Weapon* Nation::getWp() const {
	return m_Wp; 
}
Medicine* Nation::getMd() const {
	return m_Md; 
}
Food* Nation::getFd() const { 
	return m_Fd; 
}


NormalState* NormalState::p_Instance = nullptr;
NormalState::~NormalState(){
	delete p_Instance;
}
NormalState* NormalState::Instance()
{
	if (p_Instance == nullptr) {
		p_Instance = new NormalState();
	}
	return p_Instance;
}
void NormalState::Click(Nation* nation)
{
	nation->SetSupplyState(SupplyState::Instance());
}


SupplyState* SupplyState::p_Instance = nullptr;
SupplyState::~SupplyState() {
	delete p_Instance;
}
SupplyState* SupplyState::Instance()
{
	if (p_Instance == nullptr) {
		p_Instance = new SupplyState();
	}
	return p_Instance;
}
void SupplyState::Click(Nation* nation)
{
	nation->SetSupplyState(NormalState::Instance());
}
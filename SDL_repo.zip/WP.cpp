#include"WP.h"

Weapon::Weapon(int amount)
	:m_Data(amount) {

}

bool Weapon::Use()
{
	if (m_Data > 0) {
		m_Data--;
		return true;
	}
	else {
		return false;
	}
}

void Weapon::Take()
{
}

int Weapon::get() const
{
	return m_Data;
}

void Weapon::set(int Data)
{
	m_Data = Data;
}

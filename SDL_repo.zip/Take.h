#pragma once

__interface ITake {
public:
	virtual void Take() =0 ;
};